from custom_pose_msg.msg._pose_custom import PoseCustom  # noqa: F401
