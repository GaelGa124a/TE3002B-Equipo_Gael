// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_POSE_MSG__MSG__POSE_CUSTOM_HPP_
#define CUSTOM_POSE_MSG__MSG__POSE_CUSTOM_HPP_

#include "custom_pose_msg/msg/detail/pose_custom__struct.hpp"
#include "custom_pose_msg/msg/detail/pose_custom__builder.hpp"
#include "custom_pose_msg/msg/detail/pose_custom__traits.hpp"
#include "custom_pose_msg/msg/detail/pose_custom__type_support.hpp"

#endif  // CUSTOM_POSE_MSG__MSG__POSE_CUSTOM_HPP_
