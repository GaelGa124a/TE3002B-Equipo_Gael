// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custom_pose_msg:msg/PoseCustom.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_POSE_MSG__MSG__DETAIL__POSE_CUSTOM__BUILDER_HPP_
#define CUSTOM_POSE_MSG__MSG__DETAIL__POSE_CUSTOM__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custom_pose_msg/msg/detail/pose_custom__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custom_pose_msg
{

namespace msg
{

namespace builder
{

class Init_PoseCustom_time
{
public:
  explicit Init_PoseCustom_time(::custom_pose_msg::msg::PoseCustom & msg)
  : msg_(msg)
  {}
  ::custom_pose_msg::msg::PoseCustom time(::custom_pose_msg::msg::PoseCustom::_time_type arg)
  {
    msg_.time = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_pose_msg::msg::PoseCustom msg_;
};

class Init_PoseCustom_poses
{
public:
  Init_PoseCustom_poses()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PoseCustom_time poses(::custom_pose_msg::msg::PoseCustom::_poses_type arg)
  {
    msg_.poses = std::move(arg);
    return Init_PoseCustom_time(msg_);
  }

private:
  ::custom_pose_msg::msg::PoseCustom msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_pose_msg::msg::PoseCustom>()
{
  return custom_pose_msg::msg::builder::Init_PoseCustom_poses();
}

}  // namespace custom_pose_msg

#endif  // CUSTOM_POSE_MSG__MSG__DETAIL__POSE_CUSTOM__BUILDER_HPP_
