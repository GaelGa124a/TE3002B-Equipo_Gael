// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_pose_msg:msg/PoseCustom.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_POSE_MSG__MSG__POSE_CUSTOM_H_
#define CUSTOM_POSE_MSG__MSG__POSE_CUSTOM_H_

#include "custom_pose_msg/msg/detail/pose_custom__struct.h"
#include "custom_pose_msg/msg/detail/pose_custom__functions.h"
#include "custom_pose_msg/msg/detail/pose_custom__type_support.h"

#endif  // CUSTOM_POSE_MSG__MSG__POSE_CUSTOM_H_
