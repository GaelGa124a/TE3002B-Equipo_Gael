// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from custom_pose_msg:msg/PoseCustom.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_POSE_MSG__MSG__DETAIL__POSE_CUSTOM__STRUCT_H_
#define CUSTOM_POSE_MSG__MSG__DETAIL__POSE_CUSTOM__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'poses'
#include "geometry_msgs/msg/detail/pose__struct.h"

/// Struct defined in msg/PoseCustom in the package custom_pose_msg.
typedef struct custom_pose_msg__msg__PoseCustom
{
  geometry_msgs__msg__Pose__Sequence poses;
  double time;
} custom_pose_msg__msg__PoseCustom;

// Struct for a sequence of custom_pose_msg__msg__PoseCustom.
typedef struct custom_pose_msg__msg__PoseCustom__Sequence
{
  custom_pose_msg__msg__PoseCustom * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_pose_msg__msg__PoseCustom__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CUSTOM_POSE_MSG__MSG__DETAIL__POSE_CUSTOM__STRUCT_H_
