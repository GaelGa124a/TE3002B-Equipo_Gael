# path follower with open loop control

import rclpy
from rclpy.node import Node
import numpy as np
from geometry_msgs.msg import Twist
from custom_pose_msg.msg import PoseCustom    #  custom msg with Pose and time


class OpenLoopController(Node):
    def __init__(self):
        super().__init__('open_loop_controller')
        self.wait_for_ros_time()

        # Publisher para cmd_vel
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        
        # Declarar parámetros 
        # self.declare_parameter('points', [])  # Lista vacía como default
        # self.declare_parameter('time_per_segment', 0.0)  # 0 como default
        # self.load_parameters()

        # pose subscriber 
        self.pose_sub = self.create_subscription(PoseCustom, 'pose', self.callback, 10)
        
        
        # variables de control
        self.state_start_time = self.get_clock().now()
        self.segment_count = 0
        self.state = -1  # -1: Initial rotation; 0: Move straight; 1: Rotate; 2: Stop
        self.current_linear_speed = 0.0
        self.angular_speed = 0.5  # rad/s (fijo para giros)
        self.current_angle_diff = 0.0

        self.timer_period = 0.1
        self.timer = self.create_timer(self.timer_period, self.control_loop)
        
        self.get_logger().info('Controlador inicializado con trayectoria recibida por parámetros')

    def load_parameters(self):
        """Cargar y procesar parámetros"""
        points = self.get_parameter('points').get_parameter_value().double_array_value
        self.time_per_segment = self.get_parameter('time_per_segment').get_parameter_value().double_value
        
        # Convertir puntos a lista de tuplas [(x1,y1), (x2,y2), ...]
        if len(points) % 2 == 0: 
            self.points = [(points[i], points[i+1]) for i in range(0, len(points), 2)]
        else:
            self.points = []

    def compute_angle_between_segments(self, p0, p1, p2):
        """Calcular ángulo entre segmentos"""
        angle_prev = np.arctan2(p1[1] - p0[1], p1[0] - p0[0])
        angle_next = np.arctan2(p2[1] - p1[1], p2[0] - p1[0])
        angle_diff = angle_next - angle_prev
        return np.arctan2(np.sin(angle_diff), np.cos(angle_diff))

    def compute_segment_velocity(self):
        """Calcular velocidad lineal para el segmento actual"""
        p0 = self.points[self.segment_count]
        p1 = self.points[(self.segment_count + 1) % len(self.points)]
        distance = np.sqrt((p1[0] - p0[0])**2 + (p1[1] - p0[1])**2)
        return distance / self.time_per_segment

    def control_loop(self):
        now = self.get_clock().now()
        elapsed_time = (now - self.state_start_time).nanoseconds * 1e-9
        cmd = Twist()

        if self.state == -1:  # Rotación inicial
            cmd.linear.x = 0.0
            cmd.angular.z = self.angular_speed
            
            if len(self.points) >= 2:
                p0, p1 = self.points[0], self.points[1]
                initial_angle = np.arctan2(p1[1] - p0[1], p1[0] - p0[0])
                tiempo_giro_inicial = abs(initial_angle) / self.angular_speed
            
            if elapsed_time >= tiempo_giro_inicial:
                self.state = 0
                self.state_start_time = now
                self.current_linear_speed = self.compute_segment_velocity()

        elif self.state == 0:  # Movimiento recto
            cmd.linear.x = self.current_linear_speed
            cmd.angular.z = 0.0
            
            if elapsed_time >= self.time_per_segment:
                self.state = 1
                self.state_start_time = now
                if len(self.points) >= 3:
                    idx_prev = self.segment_count
                    idx_curr = (self.segment_count + 1) % len(self.points)
                    idx_next = (self.segment_count + 2) % len(self.points)
                    p0, p1, p2 = self.points[idx_prev], self.points[idx_curr], self.points[idx_next]
                    self.current_angle_diff = self.compute_angle_between_segments(p0, p1, p2)

        elif self.state == 1:  # Rotación
            cmd.linear.x = 0.0
            cmd.angular.z = np.sign(self.current_angle_diff) * self.angular_speed
            
            tiempo_giro = abs(self.current_angle_diff) / self.angular_speed
            if elapsed_time >= tiempo_giro:
                self.segment_count += 1
                if self.segment_count >= len(self.points) - 1:
                    self.state = 2
                else:
                    self.state = 0
                    self.current_linear_speed = self.compute_segment_velocity()
                self.state_start_time = now

        elif self.state == 2:  # Detener
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            self.cmd_vel_pub.publish(cmd)
            self.timer.cancel()
            return

        self.cmd_vel_pub.publish(cmd)

    def wait_for_ros_time(self):
        """Esperar a que el tiempo de ROS esté activo"""
        while rclpy.ok():
            now = self.get_clock().now()
            if now.nanoseconds > 0:
                break
            rclpy.spin_once(self, timeout_sec=0.1)

def main(args=None):
    rclpy.init(args=args)
    node = OpenLoopController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()