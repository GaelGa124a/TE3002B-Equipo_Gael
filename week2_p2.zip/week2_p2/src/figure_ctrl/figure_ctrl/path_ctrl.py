import rclpy
from rclpy.node import Node
import numpy as np
from geometry_msgs.msg import Twist
from custom_pose_msg.msg import PoseCustom

def normalize_angle(angle):
    """Normaliza un ángulo al rango [-pi, pi]."""
    return (angle + np.pi) % (2 * np.pi) - np.pi

class PathControl(Node):
    def __init__(self):
        super().__init__('path_ctrl')

        # Publicador y suscriptor
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.pose_sub = self.create_subscription(PoseCustom, 'pose', self.path_callback, 10)

        self.timer = self.create_timer(0.1, self.control_loop)

        # Condiciones iniciales
        self.state_start_time = self.get_clock().now()
        self.state = 0   # 0: ROTATE, 1: MOVE, 2: STOP
        self.current_segment = 0

        self.path = []  # Lista de waypoints (cada waypoint es una tupla (x,y))
        self.total_time = 0.0  # Tiempo total asignado en el mensaje
        self.segment_time = 0.0  # Tiempo asignado a cada segmento
        self.running = False

        self.linear_speed = 0.2   # m/s
        self.angular_speed = 0.5  # rad/s

        # Variable para mantener la orientación actual del robot
        self.current_angle = 0.0

        self.get_logger().info('Path follower with state machine initialized.')

    def path_callback(self, msg):
        # Se recibe la ruta completa
        self.total_time = msg.time
        self.path = [(pose.position.x, pose.position.y) for pose in msg.poses]

        if len(self.path) < 2:
            self.get_logger().error('Path needs at least 2 points.')
            return

        # Se calcula el tiempo asignado a cada segmento
        self.segment_time = self.total_time / (len(self.path) - 1)

        self.running = True
        self.current_segment = 0
        self.state = 0  # Empezar por rotar hacia el primer segmento
        self.state_start_time = self.get_clock().now()

        # Reiniciamos la orientación inicial (se asume que al inicio está a 0 rad)
        self.current_angle = 0.0

        self.get_logger().info(f'Path received with {len(self.path)} points.')

    def control_loop(self):
        # Si no se está ejecutando o se alcanzó el último segmento, se para el robot
        if not self.running or self.current_segment >= len(self.path) - 1:
            self.publish_stop()
            return

        now = self.get_clock().now()
        elapsed = (now - self.state_start_time).nanoseconds * 1e-9
        cmd = Twist()

        # Definir el segmento actual y el siguiente
        p0 = np.array(self.path[self.current_segment])
        p1 = np.array(self.path[self.current_segment + 1])
        delta = p1 - p0  # Diferencia entre el waypoint actual y el siguiente

        # Cálculo del ángulo objetivo basado en la dirección del segmento
        target_angle = np.arctan2(delta[1], delta[0])
        # Calcular diferencia de ángulo necesaria (tomando en cuenta la orientación actual)
        delta_angle = normalize_angle(target_angle - self.current_angle)
        # Tiempo necesario para la rotación con la velocidad angular configurada
        rotate_time = abs(delta_angle) / self.angular_speed

        # Cálculo de la distancia con la fórmula correcta
        distance_to_target = np.sqrt((p1[0] - p0[0])**2 + (p1[1] - p0[1])**2)
        move_time = distance_to_target / self.linear_speed

        if self.state == 0:  # ROTATE
            # Comando de rotación: se gira según la diferencia calculada
            cmd.angular.z = np.sign(delta_angle) * self.angular_speed
            self.get_logger().info(f'State 0: Rotating by {delta_angle:.2f} rad (target: {target_angle:.2f} rad)')
            # Si se completó el tiempo de giro
            if elapsed >= rotate_time:
                # Actualizar la orientación actual (ahora es el ángulo objetivo)
                self.current_angle = target_angle
                self.state = 1  # Pasa al estado de MOverse
                self.state_start_time = now
                self.get_logger().info('Finished rotation. Moving to State 1.')

        elif self.state == 1:  # MOVE
            cmd.linear.x = self.linear_speed
            self.get_logger().info(f'State 1: Moving forward {distance_to_target:.2f} meters')
            if elapsed >= move_time:
                # Al finalizar el segmento, avanzar al siguiente waypoint
                self.current_segment += 1
                if self.current_segment >= len(self.path) - 1:
                    self.state = 2  # Se ha alcanzado el último punto: detenerse
                    self.get_logger().info('Reached final point. Stopping.')
                else:
                    self.state = 0  # Se pasa al estado de rotación para el siguiente segmento
                    self.get_logger().info(f'Reached waypoint {self.current_segment}. Rotating to next segment.')
                self.state_start_time = now

        elif self.state == 2:  # STOP
            self.publish_stop()
            self.running = False
            self.get_logger().info('Stopped at final goal.')
            return

        self.cmd_vel_pub.publish(cmd)

    def publish_stop(self):
        stop_cmd = Twist()
        self.cmd_vel_pub.publish(stop_cmd)

def main(args=None):
    rclpy.init(args=args)
    node = PathControl()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()