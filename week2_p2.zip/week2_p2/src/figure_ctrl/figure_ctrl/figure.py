# figure follower with open loop control

import rclpy
from rclpy.node import Node
import numpy as np
from geometry_msgs.msg import Twist

class OpenLoopCtrl(Node):
    def __init__(self):
        super().__init__('open_loop_ctrl')

        self.wait_for_ros_time()

        # Publisher to /cmd_vel
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)

        self.state_start_time = self.get_clock().now()

        # Declare parameter for number of sides (default triangle)
        self.declare_parameter('sides', 3)
        self.sides = self.get_parameter('sides').get_parameter_value().integer_value

        # State machine variables:
        # 0: Move forward; 1: Rotate; 2: Stop
        self.state = 0
        self.side_count = 0  # Track number of sides completed

        self.linear_speed = 0.2  # m/s
        self.angular_speed = 0.5  # rad/s

        self.forward_time = 0.5 / self.linear_speed  # Time to move 50cm

        # Compute rotation duration:
        angle_rad = (2 * np.pi) / self.sides
        self.rotate_time = angle_rad / self.angular_speed

        # Timer to update state machine (10 Hz)
        self.timer_period = 0.2
        self.timer = self.create_timer(self.timer_period, self.control_loop)

        self.get_logger().info(f'Figure follower initialized for a {self.sides}-sided figure.')

    def control_loop(self, msg):
        now = self.get_clock().now()
        elapsed_time = (now - self.state_start_time).nanoseconds * 1e-9
        cmd = Twist()

        # get position and orientation goal 
        # move robot to desired position and orientatio
        # estimate angular and linear velocity for next point 

        if self.state == 0:  # Moving forward
            cmd.linear.x = self.linear_speed
            cmd.angular.z = 0.0
            self.get_logger().info(f'Moving forward for side {self.side_count + 1}/{self.sides}')
            if elapsed_time >= self.forward_time:
                # Finished moving forward; now rotate.
                self.state = 1
                self.state_start_time = now
                self.get_logger().info('Finished forward motion. Starting rotation...')

        elif self.state == 1:  # Rotating
            cmd.linear.x = 0.0
            cmd.angular.z = self.angular_speed
            self.get_logger().info(f'Rotating for side {self.side_count + 1}/{self.sides}')
            if elapsed_time >= self.rotate_time:
                self.side_count += 1
                if self.side_count >= self.sides:
                    self.state = 2  # All sides complete; stop.
                    self.get_logger().info('Completed the figure. Stopping.')
                else:
                    self.state = 0  # Start next side
                    self.get_logger().info(f'Completed side {self.side_count}. Moving forward for next side.')
                self.state_start_time = now

        elif self.state == 2:  # Stop
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            self.get_logger().info('Stopped.')
            self.cmd_vel_pub.publish(cmd)
            self.timer.cancel()  # Stop the state machine
            return

        # Publish the command for the current state
        self.cmd_vel_pub.publish(cmd)

    def wait_for_ros_time(self):
        self.get_logger().info('Waiting for ROS time to become active...')
        while rclpy.ok():
            now = self.get_clock().now()
            if now.nanoseconds > 0:
                break
            rclpy.spin_once(self, timeout_sec=0.1)
        self.get_logger().info(f'ROS time is active! Start time: {now.nanoseconds * 1e-9:.2f}s')

def main(args=None):
    rclpy.init(args=args)
    node = OpenLoopCtrl()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()
        node.destroy_node()

if __name__ == '__main__':
    main()
