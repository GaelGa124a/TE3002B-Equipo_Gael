import rclpy
from rclpy.node import Node
from custom_pose_msg.msg import PoseCustom  # Mensaje custom: contiene geometry_msgs/Pose[] poses y float64 time
from geometry_msgs.msg import Pose

class PathGenerator(Node):
    def __init__(self):
        super().__init__('path_generator')
        
        # Publicador para el topic 'pose'
        self.pose_pub = self.create_publisher(PoseCustom, 'pose', 10)
        
        # Declaramos el parámetro "path" como una lista plana.
        # Cada waypoint se define con 8 valores:
        # [position.x, position.y, position.z, orientation.x, orientation.y, orientation.z, orientation.w, time]
        # Para formar un cuadrado se definen 5 waypoints, donde el primer y último punto son iguales.
        self.declare_parameter('path', [
            0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 3.0,   # Waypoint 1: iniciar en (0, 0)
            1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 6.0,   # Waypoint 2: moverse a (1, 0)
            1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 9.0,   # Waypoint 3: moverse a (1, 1)
            0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 12.0,  # Waypoint 4: moverse a (0, 1)
            0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 15.0   # Waypoint 5: retornar a (0, 0)
        ])
        
        # Se crea un timer para llamar al método que publica la ruta completa.
        # Se publicará la ruta en un único mensaje PoseCustom.
        self.timer = self.create_timer(1.0, self.publish_complete_route)

    def publish_complete_route(self):
        # Obtenemos el parámetro "path"
        path_vals = self.get_parameter('path').get_parameter_value().double_array_value
        
        if len(path_vals) % 8 != 0:
            self.get_logger().warn('La longitud de los datos del path no es múltiplo de 8.')
            return
        
        # Se agrupa la lista plana en waypoints, cada uno de 8 elementos.
        waypoints = [path_vals[i:i+8] for i in range(0, len(path_vals), 8)]
        if len(waypoints) < 2:
            self.get_logger().warn('Path needs at least 2 points.')
            return
        
        # Se crea la lista de objetos Pose para cada waypoint.
        poses = []
        for wp in waypoints:
            p = Pose()
            p.position.x = wp[0]
            p.position.y = wp[1]
            p.position.z = wp[2]
            p.orientation.x = wp[3]
            p.orientation.y = wp[4]
            p.orientation.z = wp[5]
            p.orientation.w = wp[6]
            poses.append(p)
        
        # Se arma el mensaje custom con la ruta completa.
        msg = PoseCustom()
        msg.poses = poses
        # Se asigna el tiempo total a partir del último waypoint (o según otro criterio).
        msg.time = waypoints[-1][7]
        
        self.pose_pub.publish(msg)
        self.get_logger().info(f'Publicado ruta completa con {len(poses)} waypoints y tiempo total {msg.time}')
        
        # Se cancela el timer para publicar una única vez.
        self.timer.cancel()

def main(args=None):
    rclpy.init(args=args)
    node = PathGenerator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()